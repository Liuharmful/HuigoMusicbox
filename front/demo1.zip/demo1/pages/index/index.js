// pages/index/index.js
Page({
    navigateToHeBut() {
      wx.navigateTo({
        url: '/pages/webview/webview'
      })
    }
  })