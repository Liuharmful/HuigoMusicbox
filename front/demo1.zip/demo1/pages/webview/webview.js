// pages/webview/webview.js
Page({
    onLoad(options) {
      this.setData({ url: options.url })
    }
  })